<?php
$conn = mysqli_connect('localhost','root','','mydkm');


if(!$conn){
	echo 'gagal terhubung ke database';
}
?>